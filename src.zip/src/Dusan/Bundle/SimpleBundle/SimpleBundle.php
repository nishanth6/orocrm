<?php

namespace Dusan\Bundle\SimpleBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SimpleBundle extends Bundle
{
}
