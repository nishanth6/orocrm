<?php

namespace Smiled\Bundle\MerchantBundle\Controller;

//use Symfony\Bundle\FrameworkBundle\Controller\Controller;


use FOS\RestBundle\Util\Codes;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

class DefaultController extends Controller {

    public function indexAction() {
        return $this->render('MerchantBundle:Default:index.html.twig');
    }

    public function createAction() {
        return $this->render('MerchantBundle:Default:update.html.twig');
    }

    public function campaignsAction() {
        $em = $this->getDoctrine()->getManager();
        $campaigns = $em->createQuery('select c from MerchantBundle:Campaign c')
                ->getResult(\Doctrine\ORM\Query::HYDRATE_ARRAY);

        if ($campaigns) {
            $status = Codes::HTTP_OK;
        } else {
            $status = Codes::HTTP_BAD_REQUEST;
        }
        return new JsonResponse($campaigns, $status);
    }

    public function merchantsAction() {
        $em = $this->getDoctrine()->getManager();
        $merchants = $em->createQuery('select m from MerchantBundle:Merchant m')
                ->getResult(\Doctrine\ORM\Query::HYDRATE_ARRAY);
        if ($merchants) {
            $status = Codes::HTTP_OK;
        } else {
            $status = Codes::HTTP_BAD_REQUEST;
        }
        return new JsonResponse($merchants, $status);
    }

    public function smiledusersAction() {
        $em = $this->getDoctrine()->getManager();
        $smiledusers = $em->createQuery('select m from MerchantBundle:UserProfile m')
                ->getResult(\Doctrine\ORM\Query::HYDRATE_ARRAY);
        if ($smiledusers) {
            $status = Codes::HTTP_OK;
        } else {
            $status = Codes::HTTP_BAD_REQUEST;
        }
        return new JsonResponse($smiledusers, $status);
    }

    public function autocompleteuserAction(Request $request) {
        $names = array();
        $term = trim(strip_tags($request->get('term')));
        $em = $this->getDoctrine()->getManager();
        $entities = $em->getRepository('MerchantBundle:UserProfile')->createQueryBuilder('u')
                ->andWhere('u.username LIKE :username')
                ->setParameter('username', '%' . $term . '%')
                ->getQuery()
                ->getResult();
        foreach ($entities as $entity) {
            $names[] = $entity->getUsername();
        }
        $response = new JsonResponse();
        $response->setData($names);
        return $response;
    }

    public function autocompletemerchantAction(Request $request) {
        $names = array();
        $term = trim(strip_tags($request->get('term')));
        $em = $this->getDoctrine()->getManager();
        $entities = $em->getRepository('MerchantBundle:Merchant')->createQueryBuilder('c')
                ->where('c.name LIKE :name')
                ->setParameter('name', '%' . $term . '%')
                ->getQuery()
                ->getResult();

        foreach ($entities as $entity) {
            $names[] = $entity->getName();
        }
        $response = new JsonResponse();
        $response->setData($names);
        return $response;
    }

    public function imageuploadAction(Request $request) {
        //$data =   $request->get('upload_img');
        
        
        $file = $request->files->get('upload_img');
        $status = array('status' => "success","fileUploaded" => false);
  
        // If a file was uploaded
        if(!is_null($file)){
           // generate a random name for the file but keep the extension
           $originalFileName = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
           $filename = $originalFileName. "_". uniqid().".".$file->getClientOriginalExtension();
           $path = "public/notifications/general";
           $file->move($path,$filename); // move the file to a path
           $status = array('status' => "success","fileUploaded" => true);
        }

   return new JsonResponse($status);
         
//        $p = new Image();
//        $form = $this->createForm(ImageType::class, $p);
//
//        if ($request->getMethod() == Request::METHOD_POST) {
//            $form->handleRequest($request);
//
//            if ($form->isValid()) {
//                $m = $this->getDoctrine()->getManager();
//                $m->persist($p);
//                $m->flush();
//
//                return $this->redirectToRoute('app_index_index');
//            }
//        }
//
//        return $this->render(':index:upload.html.twig', [
//            'form' => $form->createView(),
//        ]); 
    }
    
    public function imageuploadmovementsAction(Request $request) {
        //$data =   $request->get('upload_img');
        
        
        $file = $request->files->get('upload_img_movements');
        $status = array('status' => "success","fileUploaded" => false);
  
        // If a file was uploaded
        if(!is_null($file)){
           // generate a random name for the file but keep the extension
           $originalFileName = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
           $filename = $originalFileName. "_". uniqid().".".$file->getClientOriginalExtension();
           $path = "public/notifications/movements";
           $file->move($path,$filename); // move the file to a path
           $status = array('status' => "success","fileUploaded" => true);
        }

   return new JsonResponse($status);

    }
}
