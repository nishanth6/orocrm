/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



$(document).ready(function () {

    // Get all campaigns
        get_allcampaigns();
    
    // Save FORM data : 
       $( "#notification_form" ).submit(function( event ) {
          //alert( "Handler for .submit() called." );
          var formdata =  new FormData(this);
        
         //var formdata =  $(this).serialize();
         console.log(formdata);
         debugger;
           $.ajax({
            url: saveNotificationData,
            data : formdata,
            type: 'POST',
            contentType:false,
            processData:false,
            cache:false,
 
            dataType: 'json',
            data: formdata,
            async: true,
            success: function (data) {
                
            },
    
            error: function (xhr, ajaxOptions, thrownError) {
                // var errorMsg = 'Ajax request failed: ' + xhr.responseText;
                // $('#campaigns').html(errorMsg);
            }
        });
         event.preventDefault();
        });
    //END Save Form Data
    
    // Navigation Tabs
        $('.next-tab').click(function (e) {
            if ($('#tabs > .active').next('li').hasClass('next-tab')) {
                $('#tabs > li').first('li').find('a').trigger('click');
            } else {
                $('.nav-tabs > .active').next('li').find('a').trigger('click');
            }
            e.preventDefault();
        });
        $('.prev-tab').click(function (e) {
            if ($('#tabs > .active').prev('li').hasClass('prev-tab')) {
                $('#tabs > li').first('li').find('a').trigger('click');
            } else {
                $('.nav-tabs > .active').prev('li').find('a').trigger('click');
            }
            e.preventDefault();
        });
    // End Navigation Tabs
    
        $('#datetimepicker1').datetimepicker('show');
    
        $('#datetimepicker3').datetimepicker();
    
    // ImageUplodify
        $('input[type="file"]').imageuploadify();
     
        
        // $('input[type="file"]').on('change',function(){
        //     var form = document.getElementById("imageUploadForm");
        //     var fdata = new FormData(form); 
        //     console.log(fdata);
        //     $("#message").empty();
        //     var file = this.files[0];
        //     var imagefile = file.type;
        //     var match= ["image/jpeg","image/png","image/jpg"];
        //     if(!((imagefile===match[0]) || (imagefile===match[1]) || (imagefile===match[2]))){
        //         //$('#previewing').attr('src','noimage.png');
        //         $("#message").html("<p id='error'>Please Select A valid Image File</p>"+"<h4>Note</h4>"+"<span id='error_message'>Only jpeg, jpg and png Images type allowed</span>");
        //         return false;
        //     }
        //     else{
        //         $.ajax({
        //        url: saveImageGeneral,
        //        type: 'POST',
        //        contentType:false,
        //        processData:false,
        //        cache:false,
    
        //        dataType: 'json',
        //        data: fdata,
        //        async: true,
        //        success: function (data) {
        //            debugger;
        //            //$("#message").html(data);
                   
    
        //        },
    
        //        error: function (xhr, ajaxOptions, thrownError) {
        //            var errorMsg = 'Ajax request failed: ' + xhr.responseText;
        //            $('#message').html(errorMsg);
        //        }
        //        });
        //    }
        // });
        
        $("#moment").on('change',function(){
             var form2 = document.getElementById("ImageUploadMoments");
                $.ajax({
                url: saveImageMoments,
                type: 'POST',
                contentType:false,
                processData:false,
                //cache:false,
    
                dataType: 'json',
                data: new FormData(form2),
                async: true,
                success: function (data) {
                    debugger;
    
                },
    
                error: function (xhr, ajaxOptions, thrownError) {
        //            var errorMsg = 'Ajax request failed: ' + xhr.responseText;
        //            $('#campaigns').html(errorMsg);
                }
                });
        });
    // End Image Upload
     
    
    // AUTOCOMPLETE FUNCTIONS CALL 
        $("#users_auto").autocomplete({
            // source: '{{ path("notification_getsmiledusers") }}',
            source: getAutocompleteUsers,
            minLength: 1,
            select: function (event, ui) {
            }
        });
        $("#merchants_auto").autocomplete({
            // source: '{{ path("notification_getmerchants") }}',
            source: getAutocompleteMerchants,
            minLength: 1,
            select: function (event, ui) {
            }
        });
        $("#dist_merchants_auto").autocomplete({
            // source: '{{ path("notification_getmerchants") }}',
            source: getAutocompleteMerchants,
            minLength: 1,
            select: function (event, ui) {
            }
        });
    //END AUTOCOMPLETE FUNCTIONS CALL
    
    //PICK BY MODAL DIV
    
        $('.pickMerchant').click(function(e) {
            $('#pickMerchant').modal('show');
            get_all_merchants(); 
        });
        $('.merchants_list').on('change', function () {
            var merchanttext = $('.merchants_list option:selected').text();
            if (this.value != 0) {
                $(".moment_merchant").val(merchanttext);
                $("#pickMerchant .close").click()
            }
        });
    
    
        $('.pickSmiledUser').click(function(e) {
                $('#pickSmiledUser').modal('show');
                get_all_smiledusers(); 
        });
    
        $('.smiledusers_list').on('change', function () {
            var usertext = $('.smiledusers_list option:selected').text();
            if (this.value != 0) {
                $(".moment_smileduser").val(usertext);
                $("#pickSmiledUser .close").click()
            }
        });
    
    
        $('.pickDistanceMerchant').click(function (e) {
            $('#pickDistanceMerchant').modal('show');
              get_all_Merchants_inDistance(); 
          });
    
        $('.dist_merchants_list').on('change', function () {
            var mtext = $('.dist_merchants_list option:selected').text();
            if (this.value != 0) {
                $(".dist_merchants").val(mtext);
                $("#pickDistanceMerchant .close").click()
            }
        });
    //END PICK BY MODAL DIV
    
    
    });
    
    function get_allcampaigns()
    {
        
        $.ajax({
            url: getCampaigns,
            type: 'get',
            success: function (data) {
             
                html = "<option value=0>" + '[ SELECT CAMPAIGN ]' + "</option>";
                $.each(data, function (index) {
                    html += "<option value=" + data[index].id + ">" + data[index].campaign_name + "</option>"
                });
                $('.campaigns_list').append(html);
            },
    
            error: function (xhr, ajaxOptions, thrownError) {
                var errorMsg = 'Ajax request failed: ' + xhr.responseText;
                $('#campaigns').html(errorMsg);
            }
        });
    }
    
    function get_all_merchants(){
        $.ajax({
            url: getMerchants,
            type: 'get',
            success: function (data) {
                var arr = [];
                html = "<option value=0>" + '[ SELECT MERCHANTS ]' + "</option>";
                $.each(data, function (index) {
                    html += "<option value=" + data[index].id + ">" + data[index].name + "</option>"
                });
                $('.merchants_list').append(html);
            },
            error: function (xhr, ajaxOptions, thrownError) {
                var errorMsg = 'Ajax request failed: ' + xhr.responseText;
                $('#merchants').html(errorMsg);
            }
        });
    }
    
    function get_all_smiledusers(){
        $.ajax({
            url: getSmiledUsers,
            type: 'get',
            success: function (data) {
                $('.smiledusers_list').empty();
                html = "<option value=0>" + '[ SELECT USERS ]' + "</option>";
                $.each(data, function (index) {
                    html += "<option value=" + data[index].userid + ">" + data[index].username + "</option>"
                });
                $('.smiledusers_list').append(html);
            },
            error: function (xhr, ajaxOptions, thrownError) {
                var errorMsg = 'Ajax request failed: ' + xhr.responseText;
                $('#smiledusers').html(errorMsg);
            }
        });
    }
    
    function get_all_Merchants_inDistance(){
        $.ajax({
            url: getMerchants,
            type: 'get',
            success: function (data) {
    
                $('.dist_merchants_list').empty();
                var arr = [];
                html = "<option value=0>" + '[ SELECT MERCHANTS ]' + "</option>";
                $.each(data, function (index) {
                    html += "<option value=" + data[index].id + ">" + data[index].name + "</option>"
                });
                $('.dist_merchants_list').append(html);
            },
            error: function (xhr, ajaxOptions, thrownError) {
                var errorMsg = 'Ajax request failed: ' + xhr.responseText;
                $('.dist_merchants_list').html(errorMsg);
            }
        });
    }
     