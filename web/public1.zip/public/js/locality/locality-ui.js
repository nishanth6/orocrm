$(document).ready(function () {
    $("#btnCancel").on("click", function () {
        document.location.href = list_locality_url;
    });
});