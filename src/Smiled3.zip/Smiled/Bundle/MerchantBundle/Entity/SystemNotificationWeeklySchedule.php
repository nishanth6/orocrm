<?php

namespace Smiled\Bundle\MerchantBundle\Entity;


use Doctrine\ORM\Mapping as ORM;


/**
 * @ORM\Entity
 * @ORM\Table(name="sc_system_notification_weekly_schedule")
 */
class SystemNotificationWeeklySchedule
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;


    /**
     * @var integer
     *
     * @ORM\Column(name="sc_system_notification_id", type="integer")
     */
    protected $sc_system_notification_id;

    /**
     * @var string
     *
     * @ORM\Column(name="start_time", type="string", length=150)
     */
    protected $start_time;



    /**
     * @var integer
     *
     * @ORM\Column(name="weekday", type="integer", length=150)
     */
    protected $weekday;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_on", type="datetime")
     */
    private $created_on;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="modified_on", type="datetime")
     */
    private $modified_on;
 
 


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }



     /**
     * Set sc_system_notification_id
     *
     * @param integer $sc_system_notification_id
     * @return Post
     */
    public function setSystemNotificationId($sc_system_notification_id)
    {
        $this->sc_system_notification_id = $sc_system_notification_id;

        return $this;
    }
    /**
     * Get sc_system_notification_id
     *
     * @return string
     */
    public function getSystemNotificationId()
    {
        return $this->sc_system_notification_id;
    }
 
     /**
     * Set start_time
     *
     * @param string $start_time
     * @return Post
     */
    public function setStartTime($start_time)
    {
        $this->start_time = $start_time;

        return $this;
    }
    /**
     * Get start_time
     *
     * @return integer
     */
    public function getStartTime()
    {
        return $this->start_time;
    }

     /**
     * Set weekday
     *
     * @param integer $weekday
     * @return Post
     */
    public function setWeekday($weekday)
    {
        if($weekday=='on'){
            $val = 1;
        } else{
            $val = 0;
        }
        $this->weekday = $val;
        return $this;
    }
    /**
     * Get start_time
     *
     * @return integer
     */
    public function getWeekday()
    {
        return $this->weekday;
    }

    
    public function setCreatedOn($created_on)
    {
        $this->created_on = $created_on;

        return $this;
    }

    /**
     * Get created_on
     *
     * @return \DateTime
     */
    public function getCreated()
    {
        return $this->created_on;
    }

    /**
     * Set modified_on
     *
     * @param \DateTime $modified_on
     * @return Post
     */
    public function setModifiedOn($modified_on)
    {
        $this->modified_on = $modified_on;

        return $this;
    }

    /**
     * Get modified_on
     *
     * @return \DateTime
     */
    public function getModifiedOn()
    {
        return $this->modified_on;
    }

    /**
     * Auto set the modified date
     *
     * @ORM\PreUpdate
     */
    public function setModifiedValue()
    {
       $this->setModifiedOn(new \DateTime());
    }

    /**
     * Set initial value for created_on/modified_on values
     *
     * @ORM\PrePersist
     */
    public function setCreatedValues()
    {
        $this->setCreatedOn(new \DateTime());
        $this->setModifiedOn(new \DateTime());
    }
     

   

     


    







}