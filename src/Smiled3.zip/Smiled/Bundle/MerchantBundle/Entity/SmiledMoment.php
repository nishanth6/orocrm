<?php
namespace Smiled\Bundle\MerchantBundle\Entity;


use Doctrine\ORM\Mapping as ORM;

/**
 * SmiledMoment
 *
 * @ORM\Table(name="smiled_moment")
 * @ORM\Entity
 */
class SmiledMoment
{
    /**
     * @var string
     *
     * @ORM\Column(name="smiled_id", type="string", length=40, nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $smiledId;

    /**
     * @var string
     *
     * @ORM\Column(name="user_id", type="string", length=40, nullable=false)
     */
    private $userId;

    /**
     * @var string
     *
     * @ORM\Column(name="username", type="string", length=15, nullable=true)
     */
    private $username;

    /**
     * @var string
     *
     * @ORM\Column(name="referral_code", type="string", length=50, nullable=true)
     */
    private $referralCode;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=512, nullable=true)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="media", type="string", length=255, nullable=true)
     */
    private $media;

    /**
     * @var string
     *
     * @ORM\Column(name="media_thumb", type="string", length=255, nullable=true)
     */
    private $mediaThumb;

    /**
     * @var float
     *
     * @ORM\Column(name="image_width", type="float", precision=10, scale=2, nullable=true)
     */
    private $imageWidth = '0.00';

    /**
     * @var float
     *
     * @ORM\Column(name="image_height", type="float", precision=10, scale=2, nullable=true)
     */
    private $imageHeight = '0.00';

    /**
     * @var integer
     *
     * @ORM\Column(name="smiles", type="integer", nullable=true)
     */
    private $smiles;

    /**
     * @var integer
     *
     * @ORM\Column(name="comments", type="integer", nullable=true)
     */
    private $comments;

    /**
     * @var string
     *
     * @ORM\Column(name="last_comments", type="text", length=65535, nullable=true)
     */
    private $lastComments;

    /**
     * @var string
     *
     * @ORM\Column(name="location_name", type="string", length=255, nullable=true)
     */
    private $locationName;

    /**
     * @var string
     *
     * @ORM\Column(name="lat", type="decimal", precision=18, scale=15, nullable=true)
     */
    private $lat;

    /**
     * @var string
     *
     * @ORM\Column(name="lon", type="decimal", precision=18, scale=15, nullable=true)
     */
    private $lon;

    /**
     * @var string
     *
     * @ORM\Column(name="geohash", type="string", length=16, nullable=true)
     */
    private $geohash;

    /**
     * @var integer
     *
     * @ORM\Column(name="created_on", type="bigint", nullable=true)
     */
    private $createdOn;

    /**
     * @var integer
     *
     * @ORM\Column(name="expires_on", type="integer", nullable=true)
     */
    private $expiresOn;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_deleted", type="boolean", nullable=true)
     */
    private $isDeleted = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_system", type="boolean", nullable=true)
     */
    private $isSystem = '0';

    /**
     * @var string
     *
     * @ORM\Column(name="merchant_ids", type="text", length=65535, nullable=true)
     */
    private $merchantIds;

    /**
     * @var string
     *
     * @ORM\Column(name="butype_ids", type="text", length=65535, nullable=true)
     */
    private $butypeIds;



    /**
     * Set userId
     *
     * @param string $userId
     *
     * @return SmiledMoment
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return string
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * Set username
     *
     * @param string $username
     *
     * @return SmiledMoment
     */
    public function setUsername($username)
    {
        $this->username = $username;

        return $this;
    }

    /**
     * Get username
     *
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * Set referralCode
     *
     * @param string $referralCode
     *
     * @return SmiledMoment
     */
    public function setReferralCode($referralCode)
    {
        $this->referralCode = $referralCode;

        return $this;
    }

    /**
     * Get referralCode
     *
     * @return string
     */
    public function getReferralCode()
    {
        return $this->referralCode;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return SmiledMoment
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set media
     *
     * @param string $media
     *
     * @return SmiledMoment
     */
    public function setMedia($media)
    {
        $this->media = $media;

        return $this;
    }

    /**
     * Get media
     *
     * @return string
     */
    public function getMedia()
    {
        return $this->media;
    }

    /**
     * Set mediaThumb
     *
     * @param string $mediaThumb
     *
     * @return SmiledMoment
     */
    public function setMediaThumb($mediaThumb)
    {
        $this->mediaThumb = $mediaThumb;

        return $this;
    }

    /**
     * Get mediaThumb
     *
     * @return string
     */
    public function getMediaThumb()
    {
        return $this->mediaThumb;
    }

    /**
     * Set imageWidth
     *
     * @param float $imageWidth
     *
     * @return SmiledMoment
     */
    public function setImageWidth($imageWidth)
    {
        $this->imageWidth = $imageWidth;

        return $this;
    }

    /**
     * Get imageWidth
     *
     * @return float
     */
    public function getImageWidth()
    {
        return $this->imageWidth;
    }

    /**
     * Set imageHeight
     *
     * @param float $imageHeight
     *
     * @return SmiledMoment
     */
    public function setImageHeight($imageHeight)
    {
        $this->imageHeight = $imageHeight;

        return $this;
    }

    /**
     * Get imageHeight
     *
     * @return float
     */
    public function getImageHeight()
    {
        return $this->imageHeight;
    }

    /**
     * Set smiles
     *
     * @param integer $smiles
     *
     * @return SmiledMoment
     */
    public function setSmiles($smiles)
    {
        $this->smiles = $smiles;

        return $this;
    }

    /**
     * Get smiles
     *
     * @return integer
     */
    public function getSmiles()
    {
        return $this->smiles;
    }

    /**
     * Set comments
     *
     * @param integer $comments
     *
     * @return SmiledMoment
     */
    public function setComments($comments)
    {
        $this->comments = $comments;

        return $this;
    }

    /**
     * Get comments
     *
     * @return integer
     */
    public function getComments()
    {
        return $this->comments;
    }

    /**
     * Set lastComments
     *
     * @param string $lastComments
     *
     * @return SmiledMoment
     */
    public function setLastComments($lastComments)
    {
        $this->lastComments = $lastComments;

        return $this;
    }

    /**
     * Get lastComments
     *
     * @return string
     */
    public function getLastComments()
    {
        return $this->lastComments;
    }

    /**
     * Set locationName
     *
     * @param string $locationName
     *
     * @return SmiledMoment
     */
    public function setLocationName($locationName)
    {
        $this->locationName = $locationName;

        return $this;
    }

    /**
     * Get locationName
     *
     * @return string
     */
    public function getLocationName()
    {
        return $this->locationName;
    }

    /**
     * Set lat
     *
     * @param string $lat
     *
     * @return SmiledMoment
     */
    public function setLat($lat)
    {
        $this->lat = $lat;

        return $this;
    }

    /**
     * Get lat
     *
     * @return string
     */
    public function getLat()
    {
        return $this->lat;
    }

    /**
     * Set lon
     *
     * @param string $lon
     *
     * @return SmiledMoment
     */
    public function setLon($lon)
    {
        $this->lon = $lon;

        return $this;
    }

    /**
     * Get lon
     *
     * @return string
     */
    public function getLon()
    {
        return $this->lon;
    }

    /**
     * Set geohash
     *
     * @param string $geohash
     *
     * @return SmiledMoment
     */
    public function setGeohash($geohash)
    {
        $this->geohash = $geohash;

        return $this;
    }

    /**
     * Get geohash
     *
     * @return string
     */
    public function getGeohash()
    {
        return $this->geohash;
    }

    /**
     * Set createdOn
     *
     * @param integer $createdOn
     *
     * @return SmiledMoment
     */
    public function setCreatedOn($createdOn)
    {
        $this->createdOn = $createdOn;

        return $this;
    }

    /**
     * Get createdOn
     *
     * @return integer
     */
    public function getCreatedOn()
    {
        return $this->createdOn;
    }

    /**
     * Set expiresOn
     *
     * @param integer $expiresOn
     *
     * @return SmiledMoment
     */
    public function setExpiresOn($expiresOn)
    {
        $this->expiresOn = $expiresOn;

        return $this;
    }

    /**
     * Get expiresOn
     *
     * @return integer
     */
    public function getExpiresOn()
    {
        return $this->expiresOn;
    }

    /**
     * Set isDeleted
     *
     * @param boolean $isDeleted
     *
     * @return SmiledMoment
     */
    public function setIsDeleted($isDeleted)
    {
        $this->isDeleted = $isDeleted;

        return $this;
    }

    /**
     * Get isDeleted
     *
     * @return boolean
     */
    public function getIsDeleted()
    {
        return $this->isDeleted;
    }

    /**
     * Set isSystem
     *
     * @param boolean $isSystem
     *
     * @return SmiledMoment
     */
    public function setIsSystem($isSystem)
    {
        $this->isSystem = $isSystem;

        return $this;
    }

    /**
     * Get isSystem
     *
     * @return boolean
     */
    public function getIsSystem()
    {
        return $this->isSystem;
    }

    /**
     * Set merchantIds
     *
     * @param string $merchantIds
     *
     * @return SmiledMoment
     */
    public function setMerchantIds($merchantIds)
    {
        $this->merchantIds = $merchantIds;

        return $this;
    }

    /**
     * Get merchantIds
     *
     * @return string
     */
    public function getMerchantIds()
    {
        return $this->merchantIds;
    }

    /**
     * Set butypeIds
     *
     * @param string $butypeIds
     *
     * @return SmiledMoment
     */
    public function setButypeIds($butypeIds)
    {
        $this->butypeIds = $butypeIds;

        return $this;
    }

    /**
     * Get butypeIds
     *
     * @return string
     */
    public function getButypeIds()
    {
        return $this->butypeIds;
    }

    /**
     * Get smiledId
     *
     * @return string
     */
    public function getSmiledId()
    {
        return $this->smiledId;
    }

     /**
     * Set smiledId
     *
     * @param string $smiledId
     *
     * @return SmiledMoment
     */
    public function setSmiledId($smiledId)
    {
        $this->smiledId = $smiledId;

        return $this;
    }
}
