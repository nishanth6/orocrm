<?php

namespace Smiled\Bundle\MerchantBundle\Controller;

//use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use FOS\RestBundle\Util\Codes;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Smiled\Bundle\MerchantBundle\Entity\SmiledMoment;
use Smiled\Bundle\MerchantBundle\Entity\SystemNotification;
use Smiled\Bundle\MerchantBundle\Entity\SystemNotificationWeeklySchedule;
use Smiled\Bundle\MerchantBundle\Service\ImageUploadService;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * Description of NotificationController
 *
 *
 * @Route("/")
 */
class NotificationController extends Controller
{

    /**
     * @Route("/notification/list", name="notification_index")
     * @Template()
     */
    /*public function indexAction() {
    return $this->render('MerchantBundle:Notification:index.html.twig');
    }*/
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager();
        $result = $em->createQueryBuilder();
        $notifications = $result->select('sn')
        ->from('MerchantBundle:SystemNotification', 'sn')
        ->getQuery()
        ->getResult(\Doctrine\ORM\Query::HYDRATE_ARRAY);
            $data['notifications'] = array(); 
            foreach($notifications as $notification){
            $data['notifications'][] = array(
            'id' => $notification['id'],
            'smiled_moment_id' => $notification['smiled_moment_id'],
            'name' => $notification['name'],
            'notification_image' => 'http://orocrm.example.com/public/'.$notification['notification_image'],
            'short_description' => $notification['short_description'],
            'long_description' => $notification['long_description'],
            'smiled_moment_id' => $notification['smiled_moment_id'],


            ); 
        }

        return $this->render('MerchantBundle:Notification:index.html.twig',$data);
    }

    /**
     * @Route("/notification/create", name="notification_create")
     * @Template("MerchantBundle:Notification:update.html.twig")
     */
    public function createAction()
    {
        return $this->render('MerchantBundle:Notification:update.html.twig');
    }

     /**
     * @Route("/notification/edit", name="notification_edit")
     * @Template("MerchantBundle:Notification:update.html.twig")
     */
    public function editAction(Request $request)
    { 
        $notification_id = $request->get('id');
        $em = $this->getDoctrine()->getManager();
        $notification = $em->getRepository('MerchantBundle:SystemNotification')->find($notification_id);
        $smiled_moment_id = 'aebe8750ebb1b42ceedc0081de50e1c00e8e9d27';
        $smiled_moment = $em->getRepository('MerchantBundle:SmiledMoment')->find($smiled_moment_id);
        $notification_weekly_scheduled = $em->getRepository('MerchantBundle:SystemNotificationWeeklySchedule')->findBy(array('sc_system_notification_id' => $notification_id));
        $weekly_scheduled = array(); 
        foreach($notification_weekly_scheduled as $schedule){
            if($schedule->getWeekday()=='1'){
                $weekname = 'Sunday'; 
            } else{
                $weekname = 'Monday'; 
            }
            $weekly_scheduled[] = array(
                'weekday' => $schedule->getWeekday(),
                'start_time' => $schedule->getStartTime(), 
                'weekname' => $weekname 
            );
        }   
        $merchant_name1 =  $em->getRepository('MerchantBundle:Merchant')->find($notification->getScMerchantId());
        $merchant_name2 =  $em->getRepository('MerchantBundle:Merchant')->find($smiled_moment->getMerchantIds());
        $data['notification'] = array(
           'name' => $notification->getName(),
           'id' => $notification->getId(),
           'sc_campaign_id' => $notification->getScCampaignId(),
           'short_description' => $notification->getShortDescription(),
           'long_description' => $notification->getLongDescription(),
           'notiifcation_image' => $notification->getNotificationImage(),
           'merchant_name1' => $merchant_name1->getName(),
           'notiifcation_image_thumb' => $notification->getNotificationImageThumb(),
           'has_weekly_schedule' => $notification->getHasWeeklySchedule(),
           'start_date' => $notification->getNotificationStartDate(),
           'end_date' => $notification->getNotificationEndDate(),
           'distance' => $notification->getDistance(),
           'hours' => $notification->getHours(),
           'merchant_id' => $notification->getScMerchantId(),
           'user_id' => $smiled_moment->getUserId(),
           'username' => $smiled_moment->getUsername(),
           'title' => $smiled_moment->getTitle(),
           'media' => $smiled_moment->getMedia(),
           'media_thumb' => $smiled_moment->getMediaThumb(),
           'location_name' => $smiled_moment->getLocationName(),
           'lat' => $smiled_moment->getLat(),
           'lon' => $smiled_moment->getLon(),
           'merchant_name2' => $merchant_name2->getName(),
           'merchant_ids' => $smiled_moment->getMerchantIds(),
           'weekly_scheduled' => $weekly_scheduled
        ); 

        
        // $notification = $em->getRepository('MerchantBundle:SystemNotification')->createQueryBuilder('sn')
        // ->where('sn.id = :id')
        // ->setParameter('id', $notification_id)
        // ->getQuery()
        // ->getResult();
        
   //    echo '<pre>'; var_dump($data['notification']); 

 
        return $this->render('MerchantBundle:Notification:update.html.twig',$data);
    }

    public function checkExistName($name){
        $em = $this->getDoctrine()->getManager();
        $name = $em->getRepository('MerchantBundle:SystemNotification')->findOneBy(array('name' => $name));
        
        if($name){
            return true;
        } else{
            return false; 
        }
    }

    /**
     * @Route("/notification/savedata", name="notification_save")
     *
     */
    public function savedataAction(Request $request)
    {
       $response = new JsonResponse();
     
        if(empty($request->get('name'))){
            $status = array('status' => "failure", "message" => 'Please Enter the Name');
            $response->setData($status);
            return $response;
        }

        if(empty($request->get('latitude')) && empty($request->get('latitude'))){
            $status = array('status' => "failure", "message" => 'Please Select the location');
            $response->setData($status);
            return $response;
        }

        $checkExist =  $this->checkExistName($request->get('name')); 
        if($checkExist == true){
            $status = array('status' => "failure", "message" => 'Notification Name Already Exist');
            $response->setData($status);
            return $response;
        }  

        $general_image = $request->files->get('media_image');
        $moments_image = $request->files->get('moment_image');

        $imageService = new ImageUploadService();
        if ($general_image) {
            $general_upload = $imageService->upload($general_image);
        } else {
            $general_upload = "";
        }
        if ($moments_image) {
            $moments_upload = $imageService->upload($moments_image);
        } else {
            $moments_upload = "";
        }

       
        if(empty($request->get('latitude')) && empty($request->get('latitude'))){
            $status = array('status' => "failure", "message" => 'Please Select the location');
            $response->setData($status);
            return $response;
        }

        $smiledMoment = new SmiledMoment();
        $microtime =  sha1(microtime());
        $referral_code= substr(str_shuffle(MD5(microtime())), 0, 5);
        $smiledMoment->setSmiledId($microtime);
        $smiledMoment->setUserId($request->get('smiled_user_id'));
        $smiledMoment->setUsername($request->get('username'));
        $smiledMoment->setReferralCode($referral_code);
        if ($moments_image) {
            $smiledMoment->setMedia($moments_upload['path']);
            $smiledMoment->setMediaThumb($moments_upload['thumb_path']);
            $smiledMoment->setImageWidth($moments_upload['width']);
            $smiledMoment->setImageHeight($moments_upload['height']);
        }
        $smiledMoment->setMerchantIds($request->get('sc_merchant_id'));
         $smiledMoment->setTitle($request->get('title'));
         $smiledMoment->setLat($request->get('latitude'));
         $smiledMoment->setLon($request->get('longitude'));
         $smiledMoment->setLocationName($request->get('location_name'));
         $smiledMoment->setCreatedValues();
       
        $em = $this->getDoctrine()->getManager();
        $em->persist($smiledMoment);
        $em->flush();
       
        if ($smiledMoment) {
            $microtime2 =  sha1(microtime());
            $smiled_moment_id = $smiledMoment->getSmiledId();
            $sysNotification = new SystemNotification();
            $sysNotification->setId($microtime2); 
            $sysNotification->setSmiledMomentId($microtime);
            $sysNotification->setName($request->get('name'));
            $sysNotification->setLat($request->get('latitude'));
            $sysNotification->setLon($request->get('longitude'));

            $sysNotification->setScMerchantLat('4234');
            $sysNotification->setScMerchantLon('53453');
            $sysNotification->setScCampaignId($request->get('campaign_id'));
            $sysNotification->setShortDescription($request->get('short_description'));
            $sysNotification->setLongDescription($request->get('long_description'));
            $sysNotification->setHasWeeklySchedule($request->get('has_weekly_scheduled'));
            $sysNotification->setScMerchantId($request->get('notification_dist_merchant'));
            if ($general_upload) {
                $sysNotification->setNotificationImage($general_upload['path']);
                $sysNotification->setNotificationImageThumb($general_upload['thumb_path']);
            }
            $sysNotification->setNotificationStartDate(new \DateTime($request->get('notification_start_date')));
            $sysNotification->setNotificationEndDate(new \DateTime($request->get('notification_end_date')));
            $sysNotification->setHours($request->get('hours'));
            $sysNotification->setDistance($request->get('distance'));
            $sysNotification->setCreatedValues();
            
            $em2 = $this->getDoctrine()->getManager();
            $em2->persist($sysNotification);
            $em2->flush();
            if ($sysNotification) {
                $notification_id = $sysNotification->getId();
                $weekdaytimes = $request->get('weekdaytimes');
                
                if ($weekdaytimes) {
                    $weekdaytimehas = explode(',', $weekdaytimes);
                    $separate = array();
                    foreach ($weekdaytimehas as $w) {
                        $sysNotificationWeeklySchedule = new SystemNotificationWeeklySchedule();
                        $separate = explode('-', $w);
                        $weekday = $separate[0];
                        $time = $separate[1];
                        $microtime3 =  sha1(microtime());
                        $sysNotificationWeeklySchedule->setId($microtime3);
                        $sysNotificationWeeklySchedule->setSystemNotificationId($microtime2);
                        $sysNotificationWeeklySchedule->setStartTime($time);
                        $sysNotificationWeeklySchedule->setWeekday($weekday);
                        $sysNotificationWeeklySchedule->setCreatedValues();
                        $em3 = $this->getDoctrine()->getManager();
                        $em3->persist($sysNotificationWeeklySchedule);
                        $em3->flush();
                    }
                }
            }
            $status = array('status' => "success", "message" => 'Saved Data Succesfully');
        } else {
            $status = array('status' => "failure", "message" => 'Saved Data UnSuccesfully');
        }
    
         
        $response->setData($status);
        return $response;

    }

    /**
     * @Route("/getcampaigns", name="notification_getcampaigns")
     *
     */
    public function campaignsAction()
    {
        $em = $this->getDoctrine()->getManager();
        $campaigns = $em->createQuery('select c from MerchantBundle:Campaign c')
            ->getResult(\Doctrine\ORM\Query::HYDRATE_ARRAY);

        if ($campaigns) {
            $status = Codes::HTTP_OK;
        } else {
            $status = Codes::HTTP_BAD_REQUEST;
        }
        return new JsonResponse($campaigns, $status);
    }

    /**
     * @Route("/getmerchants", name="notification_getmerchants")
     *
     */
    public function merchantsAction()
    {
        $em = $this->getDoctrine()->getManager();
        $merchants = $em->createQuery('select m from MerchantBundle:Merchant m')
            ->getResult(\Doctrine\ORM\Query::HYDRATE_ARRAY);
        if ($merchants) {
            $status = Codes::HTTP_OK;
        } else {
            $status = Codes::HTTP_BAD_REQUEST;
        }
        return new JsonResponse($merchants, $status);
    }

    /**
     * @Route("/getsmiledusers", name="notification_smiledusers")
     *
     */
    public function smiledusersAction()
    {
        $em = $this->getDoctrine()->getManager();
        $smiledusers = $em->createQuery('select m from MerchantBundle:UserProfile m')
            ->getResult(\Doctrine\ORM\Query::HYDRATE_ARRAY);
        if ($smiledusers) {
            $status = Codes::HTTP_OK;
        } else {
            $status = Codes::HTTP_BAD_REQUEST;
        }
        return new JsonResponse($smiledusers, $status);
    }

    /**
     * @Route("/autocomplete/users/search", name="notification_autocomplete_getsmiledusers")
     *
     */

    public function autocompleteuserAction(Request $request)
    {
        $names = array();
        $term = trim(strip_tags($request->get('term')));
        $em = $this->getDoctrine()->getManager();
        $entities = $em->getRepository('MerchantBundle:UserProfile')->createQueryBuilder('u')
            ->andWhere('u.username LIKE :username')
            ->setParameter('username', '%' . $term . '%')
            ->getQuery()
            ->getResult();
        foreach ($entities as $entity) {
            $names[] = array(
                'name' => $entity->getUserId(),
                'value' => $entity->getUsername(),

            );

        }
        $response = new JsonResponse();
        $response->setData($names);
        return $response;
    }

    /**
     * @Route("/autocomplete/merchant/search", name="notification_autocomplete_getmerchants")
     *
     */

    public function autocompletemerchantAction(Request $request)
    {
        $names = array();
        $term = trim(strip_tags($request->get('term')));
        $em = $this->getDoctrine()->getManager();
        $entities = $em->getRepository('MerchantBundle:Merchant')->createQueryBuilder('c')
            ->where('c.name LIKE :name')
            ->setParameter('name', '%' . $term . '%')
            ->getQuery()
            ->getResult();

        foreach ($entities as $entity) {
            //  $names[] = $entity->getName();
            $names[] = array(
                'name' => $entity->getId(),
                'value' => $entity->getName(),

            );
            //  $names[] = $entity->getName();
        }
        $response = new JsonResponse();
        $response->setData($names);
        return $response;
    }

    /**
     * @Route("/saveimage", name="notification_saveimage")
     *
     */

    public function imageuploadAction(Request $request)
    {
        //$data =   $request->get('upload_img');

        $file = $request->files->get('upload_img');

        $status = array('status' => "success", "fileUploaded" => false);

        // If a file was uploaded
        if (!is_null($file)) {
            // generate a random name for the file but keep the extension
            $originalFileName = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
            $filename = $originalFileName . "_" . uniqid() . "." . $file->getClientOriginalExtension();
            $path = "public/notifications/general";
            $file->move($path, $filename); // move the file to a path
            $status = array('status' => "success", "fileUploaded" => true);
        }

        return new JsonResponse($status);
    }

    /**
     * @Route("/saveimagemovements", name="notification_saveimagemovements")
     *
     */

    public function imageuploadmovementsAction(Request $request)
    {
        //$data =   $request->get('upload_img');

        $file = $request->files->get('upload_img_movements');
        $status = array('status' => "success", "fileUploaded" => false);

        // If a file was uploaded
        if (!is_null($file)) {
            // generate a random name for the file but keep the extension
            $originalFileName = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
            $filename = $originalFileName . "_" . uniqid() . "." . $file->getClientOriginalExtension();
            $path = "public/notifications/movements";
            $file->move($path, $filename); // move the file to a path
            $status = array('status' => "success", "fileUploaded" => true);
        }

        return new JsonResponse($status);

    }
}
