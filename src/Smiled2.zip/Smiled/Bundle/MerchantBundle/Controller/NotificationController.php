<?php

namespace Smiled\Bundle\MerchantBundle\Controller;

//use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use FOS\RestBundle\Util\Codes;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Smiled\Bundle\MerchantBundle\Entity\SystemNotification;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * Description of NotificationController
 *
 *
 * @Route("/")
 */
class NotificationController extends Controller
{

    /**
     * @Route("/notification/list", name="notification_index")
     * @Template()
     */
    /*public function indexAction() {
    return $this->render('MerchantBundle:Notification:index.html.twig');
    }*/
    public function indexAction()
    {

        return $this->render('MerchantBundle:Notification:index.html.twig');
    }

    /**
     * @Route("/notification/create", name="notification_create")
     * @Template("MerchantBundle:Notification:update.html.twig")
     */
    public function createAction()
    {

        return $this->render('MerchantBundle:Notification:update.html.twig');
    }

    /**
     * @Route("/notification/savedata", name="notification_save")
     *
     */
    public function savedataAction(Request $request)
    {
        // $data = trim($request->get('short_description'));
        // echo $data;
        // exit;
        // $data = array(
        //     'name' => $request->get('name'),
        //     'sc_campaign_id' => $request->get('name'),
        //     'short_description' => $request->get('short_description'),
        //     'long_description' => $request->get('long_description'),
        //     //'sc_campaign_id' => $request->get('name');

        // );
        // print_r($data);
        // // foreach ($request as $key => $value) {
        // //     echo $key . " has the value" . $value;
        // // }

        // // for ($i = 0; $i < count($data); $i++) {
        // //     $key = key($data);
        // //     $val = $data[$key];
        // //     if ($val != ' ') {
        // //         echo $key . " = " . $val . " <br> ";
        // //     }
        // //     next($data);
        // // }
        // //echo $data;
        // exit;

        // $response = new JsonResponse();
        // $response->setData($data);
        // return $response;

        $general_image = $request->files->get('upload_img'); 
        
        if (!is_null($general_image)) {
            // generate a random name for the file but keep the extension
            $originalFileName = pathinfo($general_image->getClientOriginalName(), PATHINFO_FILENAME);
            $filename = $originalFileName . "_" . uniqid() . "." . $general_image->getClientOriginalExtension();
            $path = "public/images/notifications/general";
            $general_image->move($path, $filename); // move the file to a path
            $status = array('status' => "success", "fileUploaded" => true);
            if($status['fileUploaded'] == "true") {
              $general_image_path =  $path.'/'.$filename;
            } else {
              $general_image_path =""; 
            }
            
        }
        $sysNotification = new SystemNotification();

        $sysNotification->setName($request->get('name'));
        $sysNotification->setScCampaignId($request->get('campaign_id'));
        $sysNotification->setShortDescription($request->get('short_description'));
        $sysNotification->setLongDescription($request->get('long_description'));
        $sysNotification->setNotificationImage($general_image_path);
        
        
        var_dump($sysNotification); 
        $em = $this->getDoctrine()->getManager();
        $em->persist($sysNotification);
        $em->flush();
        if ($sysNotification) {
            $status = array('status' => "success", "Saved Data" => true);
        } else {
            $status = array('status' => "failure", "Saved Data" => false);
        }

        $response = new JsonResponse();
        $response->setData($status);
        return $response;
    }

    /**
     * @Route("/getcampaigns", name="notification_getcampaigns")
     *
     */
    public function campaignsAction()
    {
        $em = $this->getDoctrine()->getManager();
        $campaigns = $em->createQuery('select c from MerchantBundle:Campaign c')
            ->getResult(\Doctrine\ORM\Query::HYDRATE_ARRAY);

        if ($campaigns) {
            $status = Codes::HTTP_OK;
        } else {
            $status = Codes::HTTP_BAD_REQUEST;
        }
        return new JsonResponse($campaigns, $status);
    }

    /**
     * @Route("/getmerchants", name="notification_getmerchants")
     *
     */
    public function merchantsAction()
    {
        $em = $this->getDoctrine()->getManager();
        $merchants = $em->createQuery('select m from MerchantBundle:Merchant m')
            ->getResult(\Doctrine\ORM\Query::HYDRATE_ARRAY);
        if ($merchants) {
            $status = Codes::HTTP_OK;
        } else {
            $status = Codes::HTTP_BAD_REQUEST;
        }
        return new JsonResponse($merchants, $status);
    }

    /**
     * @Route("/getsmiledusers", name="notification_smiledusers")
     *
     */
    public function smiledusersAction()
    {
        $em = $this->getDoctrine()->getManager();
        $smiledusers = $em->createQuery('select m from MerchantBundle:UserProfile m')
            ->getResult(\Doctrine\ORM\Query::HYDRATE_ARRAY);
        if ($smiledusers) {
            $status = Codes::HTTP_OK;
        } else {
            $status = Codes::HTTP_BAD_REQUEST;
        }
        return new JsonResponse($smiledusers, $status);
    }

    /**
     * @Route("/autocomplete/users/search", name="notification_autocomplete_getsmiledusers")
     *
     */

    public function autocompleteuserAction(Request $request)
    {
        $names = array();
        $term = trim(strip_tags($request->get('term')));
        $em = $this->getDoctrine()->getManager();
        $entities = $em->getRepository('MerchantBundle:UserProfile')->createQueryBuilder('u')
            ->andWhere('u.username LIKE :username')
            ->setParameter('username', '%' . $term . '%')
            ->getQuery()
            ->getResult();
        foreach ($entities as $entity) {
            $names[] = $entity->getUsername();
        }
        $response = new JsonResponse();
        $response->setData($names);
        return $response;
    }

    /**
     * @Route("/autocomplete/merchant/search", name="notification_autocomplete_getmerchants")
     *
     */

    public function autocompletemerchantAction(Request $request)
    {
        $names = array();
     
        $term = trim(strip_tags($request->get('term')));
        $em = $this->getDoctrine()->getManager();
        $entities = $em->getRepository('MerchantBundle:Merchant')->createQueryBuilder('c')
            ->where('c.name LIKE :name')
            ->setParameter('name', '%' . $term . '%')
            ->getQuery()
            ->getResult();

        foreach ($entities as $entity) {
            $names[] = $entity->getName();
        }
        $response = new JsonResponse();
        $response->setData($names);
        return $response;
    }

    /**
     * @Route("/saveimage", name="notification_saveimage")
     *
     */

    public function imageuploadAction(Request $request)
    {
        //$data =   $request->get('upload_img');

        $file = $request->files->get('upload_img');
        var_dump($file); exit;
        $status = [];
        

        // If a file was uploaded
        if (!is_null($file)) {
            // generate a random name for the file but keep the extension
            $originalFileName = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
            $filename = $originalFileName . "_" . uniqid() . "." . $file->getClientOriginalExtension();
            $path = "public/images/notifications/general";
            $file->move($path, $filename); // move the file to a path
            $status = array('status' => "success", "fileUploaded" => true);
            if($status['fileUploaded'] == "true") {
              $isimgsaved =  $path.$filename;
            } else {
                $isimgsaved =""; 
            }
            
        }
        else{
            $status = array('status' => "success", "fileUploaded" => false);
        }

        return new JsonResponse($status);
    }

    /**
     * @Route("/saveimagemovements", name="notification_saveimagemovements")
     *
     */

    public function imageuploadmovementsAction(Request $request)
    {
        //$data =   $request->get('upload_img');

        $file = $request->files->get('upload_img_movements');
        $status = array('status' => "success", "fileUploaded" => false);

        // If a file was uploaded
        if (!is_null($file)) {
            // generate a random name for the file but keep the extension
            $originalFileName = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
            $filename = $originalFileName . "_" . uniqid() . "." . $file->getClientOriginalExtension();
            $path = "public/images/notifications/movements";
            $file->move($path, $filename); // move the file to a path
            $status = array('status' => "success", "fileUploaded" => true);
        }

        return new JsonResponse($status);

    }
}
