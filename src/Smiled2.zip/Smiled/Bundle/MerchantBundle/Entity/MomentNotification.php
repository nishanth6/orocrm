<?php

namespace Smiled\Bundle\MerchantBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="smiled_moment")
 */
class MomentNotification
{
    /**
     * @var integer
     *
     * @ORM\Column(name="smiled_id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $smiled_id;

    /**
     * Get userId
     *
     * @return integer
     */
    public function getUserId()
    {
        return $this->smiled_id;
    }

    /**
     * Get lat
     *
     * @return string
     */
    public function getLat()
    {
        return $this->long_description;
    }

    /**
     * Set lat
     *
     * @param string $lat
     * @return Post
     */
    public function setLatitude($lat)
    {
        $this->lat = $lat;

        return $this;
    }

    /**
     * Get lon
     *
     * @return string
     */
    public function getLongDescrtiption()
    {
        return $this->lat;
    }

    /**
     * Set lon
     *
     * @param string $lon
     * @return Post
     */
    public function setLongitude($lat)
    {
        $this->lat = $lat;

        return $this;
    }

}
