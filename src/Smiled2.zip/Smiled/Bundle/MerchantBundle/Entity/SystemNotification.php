<?php

namespace Smiled\Bundle\MerchantBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="sc_system_notifications")
 */
class SystemNotification
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="sc_campaign_id", type="integer")
     */
    protected $sc_campaign_id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=150)
     */
    protected $name;

    /**
     * @var string
     *
     * @ORM\Column(name="short_description", type="string", length=150)
     */
    protected $short_description;

    /**
     * @var string
     *
     * @ORM\Column(name="long_description", type="string", length=150)
     */
    protected $long_description;


    /**
     * @var string
     *
     * @ORM\Column(name="notification_image", type="string", length=200)
     */
    protected $notification_image;

   
    
    
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set sc_campaign_id
     *
     * @param integer $sc_campaign_id
     * @return Post
     */
    public function setScCampaignId($sc_campaign_id)
    {
        $this->sc_campaign_id = $sc_campaign_id;

        return $this;
    }
    /**
     * Get sc_campaign_id
     *
     * @return integer
     */
    public function getScCampaignId()
    {
        return $this->sc_campaign_id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Post
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set short_description
     *
     * @param string $short_description
     * @return Post
     */
    public function setShortDescription($short_description)
    {
        $this->short_description = $short_description;

        return $this;
    }

    /**
     * Get short_description
     *
     * @return string
     */
    public function getShortDescription()
    {
        return $this->short_description;
    }

    /**
     * Set long_description
     *
     * @param string $long_description
     * @return Post
     */
    public function setLongDescription($long_description)
    {
        $this->long_description = $long_description;

        return $this;
    }

     /**
     * Set notification_image
     *
     * @param string $notification_image
     * @return Post
     */

    public function setNotificationImage($notification_image)
    { 
        $this->notification_image = $notification_image;
        return $this;
    }

    /**
     * Get notification_image
     *
     * @return string
     */
    public function getNotificationImage()
    {
        return $this->notification_image;
    }

   


    /**
     * Get longDescription
     *
     * @return string
     */
    public function getLongDescription()
    {
        return $this->long_description;
    }
}
