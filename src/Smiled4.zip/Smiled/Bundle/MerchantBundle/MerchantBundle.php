<?php

namespace Smiled\Bundle\MerchantBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MerchantBundle extends Bundle
{
}
